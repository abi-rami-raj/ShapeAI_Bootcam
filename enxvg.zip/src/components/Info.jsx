import React from "react";

function Info (){
  return(
    <div class="note">
      <h1>
       Javascript and React.js
     </h1>
     <p>
       This was my first bootcamp.
       This was an amazing bootcamp.
       This bootcamp taken by shaurya sinha sir.
       Thank you So much for this free bootcamp.
       I am very grate full to the shape AI for this wonderfull bootcamp.
       </p>
      </div>   
  )
};
export default Info;